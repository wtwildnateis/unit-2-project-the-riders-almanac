package com.ridersalmanac.riders_almanac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RidersAlmanacApplicationTests {

	@Test
	void contextLoads() {
	}

}
