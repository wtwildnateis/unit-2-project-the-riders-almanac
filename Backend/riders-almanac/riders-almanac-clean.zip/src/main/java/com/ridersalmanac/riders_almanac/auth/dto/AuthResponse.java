package com.ridersalmanac.riders_almanac.auth.dto;

public record AuthResponse(String token) {}