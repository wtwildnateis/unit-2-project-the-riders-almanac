package com.ridersalmanac.riders_almanac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RidersAlmanacApplication {

	public static void main(String[] args) {
		SpringApplication.run(RidersAlmanacApplication.class, args);
	}

}
