package com.ridersalmanac.riders_almanac.forum;

import org.springframework.data.jpa.repository.*;

public interface PostImageRepository extends JpaRepository<PostImage, Long> {}