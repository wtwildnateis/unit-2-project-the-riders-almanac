import MapWrapper from "../components/Maps/MapWrapper";

const Resources = () => {
    return (
        <>
            <div className="interactiveFtContainer">
                <MapWrapper />
            </div>
        </>
    );
};

export default Resources;